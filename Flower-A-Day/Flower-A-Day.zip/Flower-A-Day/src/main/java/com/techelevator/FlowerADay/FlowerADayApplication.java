package com.techelevator.FlowerADay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlowerADayApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlowerADayApplication.class, args);
	}

}
